QuickDown starter website

Files:
- index.html: responsive single-page website.

Preview:
Open index.html in any modern browser.

Publish free:
1. Create a GitHub account and a new repository.
2. Upload index.html to the repository root.
3. In repository Settings -> Pages, choose deploy from branch and select the main branch/root.
4. Wait for GitHub Pages to publish the site.

Important:
This is a front-end starter. It supports direct media-file URLs only and does not extract YouTube videos. To support other services, use only official APIs and permitted download methods, and ensure you have rights to the media.
